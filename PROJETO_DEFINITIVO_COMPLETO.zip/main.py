
from modulos import menu, estatisticas, conteudo
from modulos.utils import limpar_tela
from modulos.usuario import cadastro_ou_login

def main():
    limpar_tela()
    print("=== Bem-vindo à Plataforma de Inclusão Digital ===")
    usuario = cadastro_ou_login()

    while True:
        escolha = menu.menu_principal()
        if escolha == "1":
            conteudo.menu_conteudo(usuario["nome"])
        elif escolha == "2":
            estatisticas.mostrar_estatisticas()
        elif escolha == "0":
            print("Saindo...")
            break
        else:
            print("Opção inválida.")

if __name__ == "__main__":
    main()
