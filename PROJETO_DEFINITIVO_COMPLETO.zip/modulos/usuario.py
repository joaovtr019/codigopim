
import json
import os

CAMINHO = os.path.join("dados", "usuarios.json")

def carregar_usuarios():
    if not os.path.exists(CAMINHO):
        return []
    with open(CAMINHO, "r", encoding="utf-8") as f:
        return json.load(f)

def salvar_usuarios(lista):
    with open(CAMINHO, "w", encoding="utf-8") as f:
        json.dump(lista, f, indent=4, ensure_ascii=False)

def cadastro_ou_login():
    nome = input("Digite seu nome: ")
    idade = int(input("Digite sua idade: "))
    usuarios = carregar_usuarios()

    for u in usuarios:
        if u["nome"] == nome:
            print("Login realizado com sucesso.")
            return u

    novo_usuario = {"nome": nome, "idade": idade, "acessos": 0, "acertos": 0}
    usuarios.append(novo_usuario)
    salvar_usuarios(usuarios)
    print("Cadastro realizado com sucesso.")
    return novo_usuario
