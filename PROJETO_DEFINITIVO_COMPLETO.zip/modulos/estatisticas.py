
import json
import os
import statistics

CAMINHO = os.path.join("dados", "usuarios.json")

def mostrar_estatisticas():
    if not os.path.exists(CAMINHO):
        print("Nenhum dado encontrado.")
        return

    with open(CAMINHO, "r", encoding="utf-8") as f:
        usuarios = json.load(f)
        if not usuarios:
            print("Nenhum usuário registrado.")
            return

        idades = [u["idade"] for u in usuarios]
        acessos = [u.get("acessos", 0) for u in usuarios]
        acertos = [u.get("acertos", 0) for u in usuarios]

        print("\n=== Estatísticas dos Usuários ===")
        print(f"Usuários cadastrados: {len(usuarios)}")
        print(f"Idade média: {statistics.mean(idades):.2f}")
        print(f"Idade mediana: {statistics.median(idades):.2f}")
        print(f"Idade moda: {statistics.mode(idades)}")
        print(f"Média de acessos: {statistics.mean(acessos):.2f}")
        print(f"Média de acertos nos quizzes: {statistics.mean(acertos):.2f}")
