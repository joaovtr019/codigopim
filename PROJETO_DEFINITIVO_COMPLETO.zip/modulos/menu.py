
def menu_principal():
    print("\n=== Menu Principal ===")
    print("1. Acessar conteúdos")
    print("2. Ver estatísticas")
    print("0. Sair")
    return input("Escolha uma opção: ")
