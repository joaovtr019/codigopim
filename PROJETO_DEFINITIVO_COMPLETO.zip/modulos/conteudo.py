
from modulos import usuario

def atualizar_dado(nome, campo):
    usuarios = usuario.carregar_usuarios()
    for u in usuarios:
        if u["nome"] == nome:
            u[campo] = u.get(campo, 0) + 1
            break
    usuario.salvar_usuarios(usuarios)

def menu_conteudo(nome_usuario):
    while True:
        print("\n=== Conteúdo Educativo ===")
        print("1. O que é Tecnologia da Informação?")
        print("2. Fundamentos de Programação em Python")
        print("3. Boas práticas de segurança digital")
        print("4. LGPD e princípios éticos")
        print("0. Voltar")
        escolha = input("Selecione uma opção: ")

        if escolha in ["1", "2", "3", "4"]:
            atualizar_dado(nome_usuario, "acessos")

        if escolha == "1":
            print("\n--- Tecnologia da Informação ---")
            input("Pressione Enter para fazer o quiz...")
            resposta = input("Qual é um software?\n(a) Mouse\n(b) Excel\n(c) Teclado\nResposta: ")
            if resposta.lower() == "b":
                print("Correto!")
                atualizar_dado(nome_usuario, "acertos")
            else:
                print("Errado. Resposta correta: (b) Excel")
        elif escolha == "2":
            print("\n--- Fundamentos de Python ---")
            input("Pressione Enter para fazer o quiz...")
            resposta = input("Qual comando imprime na tela?\n(a) echo\n(b) print\n(c) say\nResposta: ")
            if resposta.lower() == "b":
                print("Correto!")
                atualizar_dado(nome_usuario, "acertos")
            else:
                print("Errado. Resposta correta: (b) print")
        elif escolha == "3":
            print("\n--- Segurança Digital ---")
            input("Pressione Enter para fazer o quiz...")
            resposta = input("Qual é uma boa prática?\n(a) Senha igual para tudo\n(b) Ignorar atualizações\n(c) 2FA\nResposta: ")
            if resposta.lower() == "c":
                print("Correto!")
                atualizar_dado(nome_usuario, "acertos")
            else:
                print("Errado. Resposta correta: (c)")
        elif escolha == "4":
            print("\n--- LGPD e Ética ---")
            input("Pressione Enter para fazer o quiz...")
            resposta = input("Princípio da LGPD?\n(a) Compartilhar dados\n(b) Transparência\n(c) Vender dados\nResposta: ")
            if resposta.lower() == "b":
                print("Correto!")
                atualizar_dado(nome_usuario, "acertos")
            else:
                print("Errado. Resposta correta: (b)")
        elif escolha == "0":
            break
        else:
            print("Opção inválida.")
